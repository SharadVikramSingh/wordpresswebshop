"use client";


function MethodSection(){
  return <>
    {/* working-sec start */}
    <section className="working-sec mb-210">
      <div className="wrapper">
        <div className="top-part">
          <div className="sub-title">Werkwijze</div>
          <h2>Zo werken wij</h2>
          <p>
            Van eerste gesprek tot live webshop — een helder, stap-voor-stap
            proces zonder verrassingen.
          </p>
        </div>
        <div className="inner-card">
          <div className="working-card">
            <span className="count">1</span>
            <h3>
              Kennismaking &amp; <br /> Intake
            </h3>
            <p>
              We starten altijd met een gratis en vrijblijvend gesprek. We leren
              jouw bedrijf kennen, bespreken jouw wensen en geven eerlijk advies
              over de mogelijkheden.
            </p>
          </div>
          <div className="working-card">
            <span className="count">2</span>
            <h3>
              Bouw &amp; <br /> Ontwikkeling
            </h3>
            <p>
              Onze developers bouwen jouw webshop technisch sterk, snel en veilig.
              Met WooCommerce als basis en alle gewenste koppelingen en
              functionaliteiten.
            </p>
          </div>
          <div className="working-card">
            <span className="count">3</span>
            <h3>
              Ontwerp &amp; <br /> Strategie
            </h3>
            <p>
              Op basis van de intake maken wij een op maat ontwerp dat past bij
              jouw merk en doelgroep. Jij geeft feedback, wij verfijnen — totdat
              het perfect is.
            </p>
          </div>
          <div className="working-card">
            <span className="count">4</span>
            <h3>
              Kennismaking &amp; <br />
              Intake
            </h3>
            <p>
              We starten altijd met een gratis en vrijblijvend gesprek. We leren
              jouw bedrijf kennen, bespreken jouw wensen en geven eerlijk advies
              over de mogelijkheden.
            </p>
          </div>
        </div>
      </div>
    </section>
    {/* working-sec end */}
  </>
}

export default MethodSection;